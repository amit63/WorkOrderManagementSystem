package workordersystem.model;

import static org.junit.Assert.assertTrue;
import java.text.DecimalFormat;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;
import workordersystem.model.facilityErrorMsgs;
import workordersystem.model.facility;

@RunWith(JUnitParamsRunner.class)
public class facilityTest {
	
	facility fac;
	facilityErrorMsgs FerrMsgs;
	
	@Before
	public void setUp() throws Exception {
		fac = new facility();
		FerrMsgs = new facilityErrorMsgs();
	}	

	@Test
	@FileParameters("test/JUnit_facility_test_cases.csv")
	public void test(	int testcaseNo, String action, String facilitytype, String facilityname, String errorMsg,    
						String facilitytypeerror,   String facilitynameerror, String venue, String interval) {
		String venue1 = fac.getVenue();
		String interval1 = fac.getInterval();
		fac.setAddFacility(facilitytype,facilityname,interval1,venue1) ;
		fac.validateFacility(action, fac, FerrMsgs);
		fac.setViewSpecificFacility(facilitytype,facilityname);
	    assertTrue(errorMsg.equals(FerrMsgs.getErrorMsg()));
		assertTrue(facilitytypeerror.equals(FerrMsgs.getFacilityTypeError()));
		assertTrue(facilitynameerror.equals(FerrMsgs.getFacilityNameError()));
		//assertTrue(facilitydateerror.equals(RerrMsgs.getFacilityDateError//()));
		//assertTrue(estimateofrepairerror.equals(RerrMsgs.getEstimateOfRepairError()));
	}
}