package workordersystem.model;

import static org.junit.Assert.assertTrue;
import java.text.DecimalFormat;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;
import workordersystem.data.reportDAO;
import workordersystem.model.report;
import workordersystem.model.reportErrorMsgs;

@RunWith(JUnitParamsRunner.class)
public class reportTest {
	
	
	private reportDAO fmd;
	report rep;
	reportErrorMsgs RerrMsgs;
	
	@Before
	public void setUp() throws Exception {
		rep = new report();
		RerrMsgs = new reportErrorMsgs();
		fmd = new reportDAO();
	}	

	@Test
	@FileParameters("test/JUnit_report_test_cases.csv")
	public void test(	int testcaseNo, String action, String description, String reporteddate, String errorMsg,    
						String facilitydescriptionerror,   String facilitydateerror,String assignfacilitydateerror,
						String assigneddate, String assignedto, String estimateofrepair, String facilitytype,String facilityname, String urgency) {
		
		String facilitytype1 = rep.getFacilityType();
		//System.out.println("facilitytype"+facilitytype);
		String facilityname1 = rep.getFacilityName();
		String urgency1 = rep.getUrgency();
		String reportedby = rep.getReportedby();
		rep.setMARReport( facilitytype1, facilityname1, urgency1, description, reportedby, reporteddate) ;
		rep.setSearchMAR(reporteddate);
		
		String assignedto1 = rep.getAssignedTo();
		
		String marnumber1 = rep.getMarNumber();
		String estimateofrepair1 = rep.getEstimateOfRepair();
		//String check = "Please correct the following errors";
		/* 
		 * String reporteddate = ""; String description = "";
		 */
		rep.setAssignMARReport(marnumber1, assignedto1, assigneddate, estimateofrepair1);
		
		/*
		 * reportDAO.assignMAR(rep); reportDAO.insertMAR(rep);
		 */
		
		
	    rep.validateDate(action, rep, RerrMsgs);
	    //rep.validateAssignDate(action, rep, RerrMsgs);
	    //rep.validateEsitimateOfRepair(action, rep, RerrMsgs);
	    //rep.validateAssignFacilityDate(action, rep, RerrMsgs);
	    assertTrue(errorMsg.equals(RerrMsgs.getErrorMsg()));
		assertTrue(facilitydescriptionerror.equals(RerrMsgs.getFacilityDescriptionError()));
		assertTrue(facilitydateerror.equals(RerrMsgs.getFacilityDateError()));
		assertTrue(assignfacilitydateerror.equals(RerrMsgs.getAssignFacilityDateError()));
		assertTrue(assignfacilitydateerror.equals(RerrMsgs.getAssignFacilityDateError()));
		//assertTrue(facilitydateerror.equals(RerrMsgs.getFacilityDateError//()));
		//assertTrue(estimateofrepairerror.equals(RerrMsgs.getEstimateOfRepairError()));
	}
}
