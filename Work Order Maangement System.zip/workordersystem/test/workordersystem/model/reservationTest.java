package workordersystem.model;
import static org.junit.Assert.assertTrue;
import java.text.DecimalFormat;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;
import workordersystem.model.reservation;
import workordersystem.model.reservationErrorMsgs;

@RunWith(JUnitParamsRunner.class)
public class reservationTest {
	
	reservation prof;
	reservationErrorMsgs PerrMsgs;
	
	@Before
	public void setUp() throws Exception {
		prof = new reservation();
		PerrMsgs = new reservationErrorMsgs();
	}	

	@Test
	public void test() {
		
		String a = "123";
		prof.setMarNumber(a);
		String marnumber = prof.getMarNumber();
		prof.setFacilityType(a);
		String facilitytype = prof.getFacilityType();
		prof.setFacilityName(a);
		String facilityname = prof.getFacilityName();
		prof.setInterval(a);
		String interval = prof.getInterval();
		prof.setRepairdate(a);
		String repairdate = prof.getRepairdate();
		prof.setRepairer(a);
		String repairer = prof.getRepairer();
		prof.setReservationNumber(a);
		String reservationnumber = prof.getReservationNumber();
		
		
		
		
		prof.setRequestReserve(marnumber, facilitytype, facilityname, interval, repairdate, repairer) ;
		prof.setViewSchedule(repairer);
		prof.setModifyReserve(reservationnumber,interval);
		prof.setDeleteReserve(reservationnumber);
		prof.setReservationNumber(reservationnumber);
		
		
		
		
		
	}
	
	
	

}

