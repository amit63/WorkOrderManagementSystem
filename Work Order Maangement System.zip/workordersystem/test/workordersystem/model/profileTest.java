package workordersystem.model;

import static org.junit.Assert.assertTrue;
import java.text.DecimalFormat;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;
import workordersystem.data.profileDAO;
import workordersystem.data.reportDAO;
import workordersystem.model.profileErrorMsgs;
import workordersystem.model.profile;

import org.easymock.EasyMock;

@RunWith(JUnitParamsRunner.class)
public class profileTest {
	
	private profileDAO fmd;
	profile prof;
	profileErrorMsgs PerrMsgs;
	
	@Before
	public void setUp() throws Exception {
		prof = new profile();
		PerrMsgs = new profileErrorMsgs();
	}	

	@Test
	@FileParameters("test/JUnit_profile_test_cases.csv")
	public void test(	int testcaseNo, String action, String username, String password, String lastname,String firstname,   String phone,String email,
						String utaid,String address,String zipcode, String errorMsg, String usernameerror, String passworderror,
						String lastnameerror,String firstnameerror,String phoneerror,String emailerror,String utaiderror,String addresserror,
						String zipcodeerror, String role, String state) {
		
		String role1 = prof.getRole();
		//System.out.println("facilitytype"+facilitytype);
		String state1 = prof.getState();
		prof.setRegister(username,password,lastname,
				firstname,phone,email,address,state1,zipcode,role1,utaid) ;		
		prof.setLogin(username,password) ;
		prof.setViewProfile(username) ;	
		prof.setChangeUserProfile(username,role) ;
		prof.setUpdateProfile(username) ;
		prof.setViewUserProfile(username) ;	
		
		profileDAO.checklogin(prof);

		//profileDAO.StoreListinDB(prof);
		
		//String loginerror = "Login Failed  user not found ";
		
	    prof.validateUser(action, prof, PerrMsgs);
	    prof.validateLogin(action, prof, PerrMsgs);
	    prof.validateUpdateUser(action, prof, PerrMsgs);
	    
	    assertTrue(errorMsg.equals(PerrMsgs.getErrorMsg()));
	    //assertTrue(loginerror.equals(PerrMsgs.getLoginError()));
		assertTrue(firstnameerror.equals(PerrMsgs.getFirstNameError()));
		assertTrue(lastnameerror.equals(PerrMsgs.getLastNameError()));
		assertTrue(usernameerror.equals(PerrMsgs.getUsernameError()));
		assertTrue(passworderror.equals(PerrMsgs.getPasswordError()));
		assertTrue(phoneerror.equals(PerrMsgs.getPhoneError()));
		assertTrue(utaiderror.equals(PerrMsgs.getutaidError()));
		assertTrue(addresserror.equals(PerrMsgs.getaddressError()));
		assertTrue(zipcodeerror.equals(PerrMsgs.getZipcodeError()));
		assertTrue(emailerror.equals(PerrMsgs.getEmailError()));
		


	}
	

}