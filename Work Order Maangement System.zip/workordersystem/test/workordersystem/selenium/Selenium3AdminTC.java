package workordersystem.selenium;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.junit.runners.MethodSorters;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;
import workordersystem.MMFunctions;
import workordersystem.SnapshotFunction;
import workordersystem.MMFunctions.FunctionEnum;

@RunWith(JUnitParamsRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING) // the test methods in this test file can run in any order but I prefer a fixed order
public class Selenium3AdminTC extends MMFunctions {
  private StringBuffer verificationErrors = new StringBuffer();
  private SnapshotFunction snap = new SnapshotFunction(); 
  public String sAppURL, sSharedUIMapPath, testDelay;

	
  @Before
  public void setUp() throws Exception {
//	MAGIC CODE GOES HERE 
	  System.setProperty("webdriver.chrome.driver","c:/ChromeDriver/chromedriver.exe");
	  driver = new ChromeDriver();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    prop = new Properties();	
	    prop.load(new FileInputStream("./Configuration/MM_Configuration.properties"));
		sAppURL = prop.getProperty("sAppURL");
		sSharedUIMapPath = prop.getProperty("SharedUIMap");
		testDelay=prop.getProperty("testDelay");
		prop.load(new FileInputStream(sSharedUIMapPath));
  }

  //@Test
  @FileParameters("test/admin_register_test_cases.csv")
  public void TC02a(int testCaseNumber, String username, String password, String lastname,String firstname,   String phone,String email,
			String utaid,String address,String zipcode, String errorMsg, String usernameerror, String passworderror,
			String lastnameerror,String firstnameerror,String phoneerror,String emailerror,String utaiderror,String addresserror,
			String zipcodeerror, String role, String state) throws Exception {
	String methodName= new Throwable().getStackTrace()[0].getMethodName();
    driver.get(sAppURL);
    MainApp_function(driver,FunctionEnum.register); //select register from mainpage
    register_function(driver, username, password,lastname,firstname,phone,email,utaid,address,zipcode,
    		role,state,methodName+" AdminFunction test case "+testCaseNumber);   	  
    // verify error messages
    verifyregisterErrorMessages(driver, errorMsg,usernameerror,passworderror,
			lastnameerror,firstnameerror,phoneerror,emailerror,utaiderror,addresserror,
			zipcodeerror,methodName+" verifyadminErrorMessages test case "+testCaseNumber);
  }
  
  @Test
  @FileParameters("test/login_test_cases.csv")
  public void TC02b(int testCaseNumber, String username, String password,String errorMsg, String usernameerror, 
		  						String passworderror) throws Exception {
	String methodName= new Throwable().getStackTrace()[0].getMethodName();
    driver.get(sAppURL);
    MainApp_function(driver,FunctionEnum.login); //select login from homepage
    login_function(driver, username, password, methodName+" loginFunction test case "+testCaseNumber);   	  
    // verify error messages
    verifyloginErrorMessages(driver, usernameerror,passworderror,methodName+" verifyloginErrorMessages test case "+testCaseNumber);
  }
  
  
 @Test
  @FileParameters("test/admin_changerole_test_cases.csv")
  public void TC02c(int testCaseNumber, String usernamesearched,String role, String errorMsg, String searchedusernameerror) throws Exception {
	String methodName= new Throwable().getStackTrace()[0].getMethodName();
    driver.get(sAppURL);
    //MainApp_function(driver,FunctionEnum.createMar); //select create mar from homepage
    changerole_function(driver,usernamesearched ,role,methodName+" changeUserRoleFunction test case "+testCaseNumber);
    
    	  
    // verify error messages
    verifychange_roleErrorMessages(driver, searchedusernameerror,methodName+" verifyChangeUserRoleErrorMessages test case "+testCaseNumber);
    logout(driver,methodName+" verifycreateMARErrorMessages test case "+testCaseNumber);
  
  }
  @Test
  @FileParameters("test/login_test_cases.csv")
  public void TC02d(int testCaseNumber, String username, String password,String errorMsg, String usernameerror, 
		  						String passworderror) throws Exception {
	String methodName= new Throwable().getStackTrace()[0].getMethodName();
    driver.get(sAppURL);
    MainApp_function(driver,FunctionEnum.login); //select login from homepage
    login_function(driver, username, password, methodName+" loginFunction test case "+testCaseNumber);   	  
    // verify error messages
    verifyloginErrorMessages(driver, usernameerror,passworderror,methodName+" verifyloginErrorMessages test case "+testCaseNumber);
  }
  @Test
  @FileParameters("test/admin_viewuserprofile_test_cases.csv")
  public void TC02e(int testCaseNumber, String username,String errorMsg, String usernameerror) throws Exception {
	String methodName= new Throwable().getStackTrace()[0].getMethodName();
    driver.get(sAppURL);
    verifyAdminViewProfile(driver,username);
    verifyAdminViewProfileErrorMessages(driver,errorMsg, usernameerror,methodName+" verifyloginErrorMessages test case "+testCaseNumber);
  }
  
  public void verifyAdminViewProfile(WebDriver driver,String username) throws InterruptedException{
	  driver.findElement(By.name(prop.getProperty("Txt_Login_Username"))).sendKeys("Admin");
	  Thread.sleep(1000);
	  driver.findElement(By.name(prop.getProperty("Txt_Login_Password"))).sendKeys("Admin");			   
	  driver.findElement(By.xpath(prop.getProperty("Btn_Login_Login"))).click();
	  driver.findElement(By.xpath(prop.getProperty("Txt_AdminUpdateProfile_username"))).sendKeys(username);
	  driver.findElement(By.xpath(prop.getProperty("Btn_AdminUpdateProfile_viewprofile"))).click();
	  
  }
  public void verifyAdminViewProfileErrorMessages (WebDriver driver,String errorMsg, String usernameerror, String snapShotName) {
	  try {
	  //  assertTrue(driver.findElement(By.xpath(prop.getProperty("insertCompany_errMsgError"))).getAttribute("value").equals(errorMsg));
	    //assertTrue(driver.findElement(By.xpath(prop.getProperty("Txt_AdminUpdateProfile_username_error"))).getAttribute("value").equals(errorMsg));
	    assertTrue(driver.findElement(By.xpath(prop.getProperty("Txt_AdminUpdateProfile_username_error"))).getAttribute("value").equals(usernameerror));
	    snap.takeScreenshot(driver,snapShotName);
	  }
	  catch(Exception e){
			 System.out.println("verifyAdminViewProfileErrorMessages e"+e);
		 }
  }
  
  //@Test
  @FileParameters("test/admin_updateuserprofile_test_cases.csv")
  public void TC02f(int testCaseNumber, String username, String password, String lastname,String firstname,String phone,String email,
  			String utaid,String address,String zipcode, String errorMsg, String passworderror,
  			String phoneerror,String emailerror,String addresserror,
  			String zipcodeerror, String role, String state) throws Exception {
  	String methodName= new Throwable().getStackTrace()[0].getMethodName();
    driver.get(sAppURL);
    MainApp_function(driver,FunctionEnum.updateProfile); //select register from mainpage
    update_profile(driver, password, phone,email,address,zipcode,
    		methodName+" loginFunction test case "+testCaseNumber);   	  
    // verify error messages
    verifyupdate_profileErrorMessages(driver, errorMsg,passworderror,
  			phoneerror,emailerror,addresserror,
  			zipcodeerror,methodName+" verifyloginErrorMessages test case "+testCaseNumber);
    logout(driver,methodName+" verifycreateMARErrorMessages test case "+testCaseNumber);
  }
  
  
  public void changerole_function (WebDriver driver, String username,String role, String snapShotName) throws InterruptedException {
	  driver.findElement(By.name(prop.getProperty("Txt_Login_Username"))).sendKeys("Admin");
	  //Thread.sleep(1000); 
	  driver.findElement(By.name(prop.getProperty("Txt_Login_Password"))).sendKeys("Admin");			   
	   driver.findElement(By.xpath(prop.getProperty("Btn_Login_Login"))).click();
	  Thread.sleep(1000);
	   driver.findElement(By.xpath(prop.getProperty("Txt_Admin_changerole_username"))).sendKeys(username); 
	   Thread.sleep(1000);
	   new Select(driver.findElement(By.xpath(prop.getProperty("DD_Admin_changerole")))).selectByVisibleText(role);
	   //Thread.sleep(1000);
	   driver.findElement(By.xpath(prop.getProperty("Btn_Admin_changeuser"))).click();
	//   Thread.sleep(1000);
  }
  
  
  
  public void verifychange_roleErrorMessages (WebDriver driver,String usernameerror, String snapShotName) throws InterruptedException {
		
	 // System.out.println(driver.findElement(By.xpath(prop.getProperty("Txt_Admin_changerole_usernameerror"))).getAttribute("value"));
	  //System.out.println(usernameerror);
	  //Thread.sleep(1000);
	 String x = driver.findElement(By.xpath(prop.getProperty("Txt_Admin_changerole_usernameerror"))).getAttribute("value");
	  assertTrue(x.equals(usernameerror));
	   snap.takeScreenshot(driver,snapShotName);
	   
		 
  }

@After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }
}

