package workordersystem.selenium;

import java.io.FileInputStream;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;
import org.junit.FixMethodOrder;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.junit.runners.MethodSorters;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;
import workordersystem.MMFunctions;

@RunWith(JUnitParamsRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING) // the test methods in this test file can run in any order but I prefer a fixed order
public class Selenium4RepairerTC extends MMFunctions {
  private StringBuffer verificationErrors = new StringBuffer();
  public String sAppURL, sSharedUIMapPath, testDelay;

	
  @Before
  public void setUp() throws Exception {
//	MAGIC CODE GOES HERE 
	  System.setProperty("webdriver.chrome.driver","c:/ChromeDriver/chromedriver.exe");
	  driver = new ChromeDriver();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    prop = new Properties();	
	    prop.load(new FileInputStream("./Configuration/MM_Configuration.properties"));
		sAppURL = prop.getProperty("sAppURL");
		sSharedUIMapPath = prop.getProperty("SharedUIMap");
		testDelay=prop.getProperty("testDelay");
		prop.load(new FileInputStream(sSharedUIMapPath));
  }

	
	// @Test
	  
	  @FileParameters("test/repairer_register_test_cases.csv") public void
	  TC02a(int testCaseNumber, String username, String password, String
	 lastname,String firstname, String phone,String email, String utaid,String
	  address,String zipcode, String errorMsg, String usernameerror, String
	  passworderror, String lastnameerror,String firstnameerror,String
	  phoneerror,String emailerror,String utaiderror,String addresserror, String
	  zipcodeerror, String role, String state) throws Exception {
			  String methodName= new Throwable().getStackTrace()[0].getMethodName();
		  driver.get(sAppURL);
		  MainApp_function(driver,FunctionEnum.register); //select register from mainpage
		  register_function(driver, username,password,lastname,firstname,phone,email,utaid,address,zipcode,role,state,methodName+" RepairerFunction test case "+testCaseNumber); 
		 // verify error messages 
		  verifyregisterErrorMessages(driver, errorMsg,usernameerror,passworderror,
		  lastnameerror,firstnameerror,phoneerror,emailerror,utaiderror,addresserror,
		  zipcodeerror,methodName+" verifyrepairerErrorMessages test case "
		  +testCaseNumber);
		  }
	 
  //@Test
  @FileParameters("test/login_test_cases.csv")
  public void TC02b(int testCaseNumber, String username, String password,String errorMsg, String usernameerror, 
		  						String passworderror) throws Exception {
	String methodName= new Throwable().getStackTrace()[0].getMethodName();
    driver.get(sAppURL);
    MainApp_function(driver,FunctionEnum.login); //select login from homepage
    login_function(driver, username, password, methodName+" loginFunction test case "+testCaseNumber);   	  
    // verify error messages
    verifyloginErrorMessages(driver, usernameerror,passworderror,methodName+" verifyloginErrorMessages test case "+testCaseNumber);
  }
  
  
  @Test
  @FileParameters("test/repairer_reserveinterval_test_cases.csv")
  public void TC02c(String interval) throws Exception {
	String methodName= new Throwable().getStackTrace()[0].getMethodName();
    driver.get(sAppURL);
    //MainApp_function(driver,FunctionEnum.createMar); //select create mar from homepage
    viewRepairerSchedule_function(driver,interval, methodName+" ViewRepairerSceduleFunction test case");
     //modifyReservation_function(driver,interval, methodName+" ModifyReservationFunction test case");
    //deleteReservation_function(driver,interval, methodName+" DeleteReservationFunction test case");
    // verify error messages
   // verifychange_roleErrorMessages(driver, searchedusernameerror,methodName+" verifyChangeUserRoleErrorMessages test case "+testCaseNumber);
    }
  
  
  
 // @Test
  @FileParameters("test/repairer_reserveinterval_test_cases.csv")
  public void TC02d(String interval) throws Exception {
	String methodName= new Throwable().getStackTrace()[0].getMethodName();
    driver.get(sAppURL);
    //MainApp_function(driver,FunctionEnum.createMar); //select create mar from homepage
    deleteReservation_function(driver,interval, methodName+" DeleteReservationFunction test case");
    // verify error messages
   // verifychange_roleErrorMessages(driver, searchedusernameerror,methodName+" verifyChangeUserRoleErrorMessages test case "+testCaseNumber);
    }
  
	public void deleteReservation_function (WebDriver driver,String interval,String snapShotName) throws InterruptedException {
		  
		  //Thread.sleep(1000); 
		  driver.findElement(By.name(prop.getProperty("Txt_Login_Username"))).sendKeys("Repairer1");
		  //Thread.sleep(1000); 
		  driver.findElement(By.name(prop.getProperty("Txt_Login_Password"))).sendKeys("Welcome");	
		  //Thread.sleep(1000);
		   driver.findElement(By.xpath(prop.getProperty("Btn_Login_Login"))).click();
		  //Thread.sleep(1000);   
		   driver.findElement(By.xpath(prop.getProperty("Lnk_ViewReservation"))).click();
		 // Thread.sleep(1000); //Lst_Repairer_schedule
		   driver.findElement(By.xpath(prop.getProperty("Lnk_ViewReservation_view"))).click();
		   
		   
//	new Select(driver.findElement(By.xpath(prop.getProperty("DD_RepairerReserve_interval")))).selectByVisibleText(interval);
	driver.findElement(By.xpath(prop.getProperty("Btn_DeleteReservation_delete"))).click();
}
  
	  public void viewRepairerSchedule_function (WebDriver driver,String interval,String snapShotName) throws InterruptedException {
		  
		  //Thread.sleep(1000); 
		  driver.findElement(By.name(prop.getProperty("Txt_Login_Username"))).sendKeys("Repairer1");
		  //Thread.sleep(1000); 
		  driver.findElement(By.name(prop.getProperty("Txt_Login_Password"))).sendKeys("Welcome");	
		  //Thread.sleep(1000);
		   driver.findElement(By.xpath(prop.getProperty("Btn_Login_Login"))).click();
		  //Thread.sleep(1000);   
		   driver.findElement(By.xpath(prop.getProperty("Btn_Repairer_viewSchedule"))).click();
		 // Thread.sleep(1000); //Lst_Repairer_schedule
		   driver.findElement(By.xpath(prop.getProperty("Lnk_Repairer_reserve"))).click();
		   
		   
	new Select(driver.findElement(By.xpath(prop.getProperty("DD_RepairerReserve_interval")))).selectByVisibleText(interval);
	driver.findElement(By.xpath(prop.getProperty("Btn_RepairerReserve"))).click();
	 //driver.findElement(By.id(prop.getProperty("Btn_logout"))).click();
	  }  
	  
	  public void modifyReservation_function (WebDriver driver,String interval,String snapShotName) throws InterruptedException {
		  
		  //Thread.sleep(1000); 
		  driver.findElement(By.name(prop.getProperty("Txt_Login_Username"))).sendKeys("Repairer1");
		  //Thread.sleep(1000); 
		  driver.findElement(By.name(prop.getProperty("Txt_Login_Password"))).sendKeys("Welcome");	
		  //Thread.sleep(1000);
		   driver.findElement(By.xpath(prop.getProperty("Btn_Login_Login"))).click();
		  //Thread.sleep(1000);   
		   driver.findElement(By.xpath(prop.getProperty("Lnk_ViewReservation"))).click();
		 // Thread.sleep(1000); //Lst_Repairer_schedule
		   driver.findElement(By.xpath(prop.getProperty("Lnk_ViewReservation_view"))).click();
		   
		   
	//new Select(driver.findElement(By.xpath(prop.getProperty("DD_RepairerReserve_interval")))).selectByVisibleText(interval);
	driver.findElement(By.xpath(prop.getProperty("Btn_ModifyReservation_modify"))).click();
}
	
	
@After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }
}
