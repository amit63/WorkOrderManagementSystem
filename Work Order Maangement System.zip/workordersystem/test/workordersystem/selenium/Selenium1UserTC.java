package workordersystem.selenium;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;
import org.junit.FixMethodOrder;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.junit.runners.MethodSorters;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;
import workordersystem.MMFunctions;
import workordersystem.SnapshotFunction;

@RunWith(JUnitParamsRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING) // the test methods in this test file can run in any order but I prefer a fixed order
public class Selenium1UserTC extends MMFunctions {
  private StringBuffer verificationErrors = new StringBuffer();
  public String sAppURL, sSharedUIMapPath, testDelay;
  public String uName,uPassword; 
  private SnapshotFunction snap = new SnapshotFunction(); 
	
  @Before
  public void setUp() throws Exception {

	  System.setProperty("webdriver.chrome.driver","c:/ChromeDriver/chromedriver.exe");
	  driver = new ChromeDriver();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    prop = new Properties();	
	    prop.load(new FileInputStream("./Configuration/MM_Configuration.properties"));
		sAppURL = prop.getProperty("sAppURL");
		sSharedUIMapPath = prop.getProperty("SharedUIMap");
		testDelay=prop.getProperty("testDelay");
		prop.load(new FileInputStream(sSharedUIMapPath));
  }
 
 @Test
  @FileParameters("test/register_test_cases.csv")
  public void TC02a(int testCaseNumber, String username, String password, String lastname,String firstname,   String phone,String email,
			String utaid,String address,String zipcode, String errorMsg, String usernameerror, String passworderror,
			String lastnameerror,String firstnameerror,String phoneerror,String emailerror,String utaiderror,String addresserror,
			String zipcodeerror, String role, String state) throws Exception {
	String methodName= new Throwable().getStackTrace()[0].getMethodName();
    driver.get(sAppURL);
    MainApp_function(driver,FunctionEnum.register); //select register from mainpage
    register_function(driver, username, password,lastname,firstname,phone,email,utaid,address,zipcode,
    		role,state,methodName+" loginFunction test case "+testCaseNumber);   	  
    // verify error messages
    verifyregisterErrorMessages(driver, errorMsg,usernameerror,passworderror,
			lastnameerror,firstnameerror,phoneerror,emailerror,utaiderror,addresserror,
			zipcodeerror,methodName+" verifyloginErrorMessages test case "+testCaseNumber);
  }
  
 @Test
  @FileParameters("test/login_test_cases.csv")
  public void TC02b(int testCaseNumber, String username, String password,String errorMsg, String usernameerror, 
		  						String passworderror) throws Exception {
	String methodName= new Throwable().getStackTrace()[0].getMethodName();
    driver.get(sAppURL);
    //MainApp_function(driver,FunctionEnum.login); //select login from homepage
    login_function(driver, username, password, methodName+" loginFunction test case "+testCaseNumber);   	  
    // verify error messages
    verifyloginErrorMessages(driver, usernameerror,passworderror,methodName+" verifyloginErrorMessages test case "+testCaseNumber);
   if(username.equals("John123") && password.equals("Welcome"))
	   logout(driver,methodName+" verifycreateMARErrorMessages test case "+testCaseNumber);
    
  }
  
  
 @Test
  @FileParameters("test/report_cases.csv")
  public void TC02c(int testCaseNumber, String description, String reporteddate,String errorMsg, String facilitydescriptionerror, 
		  						String facilitydateerror,String facilitytype, String facilityname, String urgency) throws Exception {
	String methodName= new Throwable().getStackTrace()[0].getMethodName();
    driver.get(sAppURL);
    MainApp_function(driver,FunctionEnum.createMar); //select create mar from homepage
    createMAR_function(driver, facilitytype, facilityname, urgency, description,reporteddate,methodName+" createMARFunction test case "+testCaseNumber);	  
    // verify error messages
    verifycreateMARErrorMessages(driver, facilitydescriptionerror,facilitydateerror,methodName+" verifycreateMARErrorMessages test case "+testCaseNumber);
    logout(driver,methodName+" verifycreateMARErrorMessages test case "+testCaseNumber);
    
  }
  
  @Test
  @FileParameters("test/login_test_cases.csv")
  public void TC02d(int testCaseNumber, String username, String password,String errorMsg, String usernameerror, 
		  						String passworderror) throws Exception {
	String methodName= new Throwable().getStackTrace()[0].getMethodName();
    driver.get(sAppURL);
    //MainApp_function(driver,FunctionEnum.login); //select login from homepage
    login_function(driver, username, password, methodName+" loginFunction test case "+testCaseNumber);   	  
    // verify error messages
    verifyloginErrorMessages(driver, usernameerror,passworderror,methodName+" verifyloginErrorMessages test case "+testCaseNumber);
   if(username.equals("John123") && password.equals("Welcome"))
	   logout(driver,methodName+" verifycreateMARErrorMessages test case "+testCaseNumber);
    
  }

//@Test
@FileParameters("test/updateprofile_test_cases.csv")
public void TC02e(int testCaseNumber, String username, String password, String lastname,String firstname,String phone,String email,
			String utaid,String address,String zipcode, String errorMsg, String passworderror,
			String phoneerror,String emailerror,String addresserror,
			String zipcodeerror, String role, String state) throws Exception {
	String methodName= new Throwable().getStackTrace()[0].getMethodName();
  driver.get(sAppURL);
  MainApp_function(driver,FunctionEnum.updateProfile); //select register from mainpage
  update_profile(driver, password, phone,email,address,zipcode,
  		methodName+" loginFunction test case "+testCaseNumber);   	  
  // verify error messages
  verifyupdate_profileErrorMessages(driver, errorMsg,passworderror,
			phoneerror,emailerror,addresserror,
			zipcodeerror,methodName+" verifyloginErrorMessages test case "+testCaseNumber);
}

public void createMAR_function (WebDriver driver, String facilityType, String facilityName, String urgency, String description, String reportedDate, String snapShotName) throws InterruptedException {
	 // //Thread.sleep(1000);
	 
	  driver.findElement(By.xpath(prop.getProperty("Btn_CreateMAR_createmar"))).click();
	  //Thread.sleep(1000); 
	  new Select(driver.findElement(By.name(prop.getProperty("Lst_CreateMAR_facilitytype")))).selectByVisibleText(facilityType);  
	  //Thread.sleep(1000);
	  new Select(driver.findElement(By.name(prop.getProperty("Lst_CreateMAR_facilityname")))).selectByVisibleText(facilityName);  
	  //Thread.sleep(1000);
	  new Select(driver.findElement(By.name(prop.getProperty("Lst_CreateMAR_urgency")))).selectByVisibleText(urgency);  
	  //Thread.sleep(1000);  
	  driver.findElement(By.name(prop.getProperty("Txt_CreateMAR_description"))).sendKeys(description);
	  //Thread.sleep(1000);  
	  driver.findElement(By.name(prop.getProperty("Txt_CreateMAR_reporteddate"))).sendKeys(reportedDate);
	    
	    snap.takeScreenshot(driver, snapShotName);
	    //Thread.sleep(1000);
	    driver.findElement(By.xpath(prop.getProperty("Btn_CreateMAR_writemar"))).click(); //click on create report button
	    //Thread.sleep(1000);
 }
public void verifycreateMARErrorMessages (WebDriver driver,String facilitydescriptionerror, String facilitydateerror, String snapShotName) {
	  //  assertTrue(driver.findElement(By.xpath(prop.getProperty("insertCompany_errMsgError"))).getAttribute("value").equals(errorMsg));
	    assertTrue(driver.findElement(By.name(prop.getProperty("CreateMAR_descriptionError"))).getAttribute("value").equals(facilitydescriptionerror));
	    assertTrue(driver.findElement(By.name(prop.getProperty("CreateMAR_dateError"))).getAttribute("value").equals(facilitydateerror));
	    snap.takeScreenshot(driver,snapShotName);
}
  
  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }
}

