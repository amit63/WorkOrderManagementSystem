package workordersystem.selenium;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.junit.runners.MethodSorters;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;
import workordersystem.MMFunctions;
import workordersystem.SnapshotFunction;
import workordersystem.MMFunctions.FunctionEnum;

@RunWith(JUnitParamsRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING) // the test methods in this test file can run in any order but I prefer a fixed order
public class Selenium2FacManagerTC extends MMFunctions {
  private StringBuffer verificationErrors = new StringBuffer();
  public String sAppURL, sSharedUIMapPath, testDelay;
  private SnapshotFunction snap = new SnapshotFunction(); 
  @Before
  public void setUp() throws Exception {
//	MAGIC CODE GOES HERE 
	  System.setProperty("webdriver.chrome.driver","c:/ChromeDriver/chromedriver.exe");
	  driver = new ChromeDriver();
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    prop = new Properties();	
	    prop.load(new FileInputStream("./Configuration/MM_Configuration.properties"));
		sAppURL = prop.getProperty("sAppURL");
		sSharedUIMapPath = prop.getProperty("SharedUIMap");
		testDelay=prop.getProperty("testDelay");
		prop.load(new FileInputStream(sSharedUIMapPath));
  }
  
  
  //@Test
  @FileParameters("test/facilitymanager_register_test_cases.csv")
  public void TC02a(int testCaseNumber, String username, String password, String lastname,String firstname,   String phone,String email,
			String utaid,String address,String zipcode, String errorMsg, String usernameerror, String passworderror,
			String lastnameerror,String firstnameerror,String phoneerror,String emailerror,String utaiderror,String addresserror,
			String zipcodeerror, String role, String state) throws Exception {
	String methodName= new Throwable().getStackTrace()[0].getMethodName();
    driver.get(sAppURL);
    MainApp_function(driver,FunctionEnum.register); //select register from mainpage
    register_function(driver, username, password,lastname,firstname,phone,email,utaid,address,zipcode,
    		role,state,methodName+" loginFunction test case "+testCaseNumber);   	  
    // verify error messages
    verifyregisterErrorMessages(driver, errorMsg,usernameerror,passworderror,
			lastnameerror,firstnameerror,phoneerror,emailerror,utaiderror,addresserror,
			zipcodeerror,methodName+" verifyloginErrorMessages test case "+testCaseNumber);
  }
  
	
	 @Test	  
	  @FileParameters("test/SearchMAR.csv") public void TC02b(int testCaseNumber,
	  String Date, String errorMsg, String dateerror) throws Exception { String
	  methodName= new Throwable().getStackTrace()[0].getMethodName();
	  driver.get(sAppURL); // MainApp_function(driver,FunctionEnum.searchMar);
	  //select search mar from search mar page 
	  searchMAR_function(driver, Date, methodName+" searchMARFunction test case "+testCaseNumber);
	  verifysearchMARErrorMessages(driver,
	  dateerror,methodName+" verifysearchMARErrorMessages test case "
	  +testCaseNumber); }
	 

  
  @Test
  @FileParameters("test/AssignMAR.csv")
  public void TC02c(int testCaseNumber, String Rname, String Date, String days) throws Exception {
	String methodName= new Throwable().getStackTrace()[0].getMethodName();
    driver.get(sAppURL);
    //MainApp_function(driver,FunctionEnum.assignMar); //select assign mar from search mar page
    assignMAR_function(driver, Rname, Date, days,methodName+" assignMARFunction test case "+testCaseNumber);
    //logout(driver,methodName+" verifycreateMARErrorMessages test case "+testCaseNumber);
     
  }
  //@Test
  public void TC02d() throws Exception {
	String methodName= new Throwable().getStackTrace()[0].getMethodName();
    driver.get(sAppURL);
    viewFacility_function(driver,methodName+" ViewFacilityFunction test case ");
    
  }
  @Test
  @FileParameters("test/viewSpecificFacility.csv")
  public void TC02e(int testCaseNumber, String facilityType, String facilityName) throws Exception {
	String methodName= new Throwable().getStackTrace()[0].getMethodName();
    driver.get(sAppURL);
    viewSpecificFacility_function(driver, facilityType, facilityName,methodName+" ViewSpecificFacilityFunction test case "+testCaseNumber);
    
  }
  
  @Test
  @FileParameters("test/addFacility.csv")
  public void TC02f(int testCaseNumber, String facilityType, String facilityName,String errorMsg,String facilitytypeerror,String facilitynameerror, String Intreval,String Venue) throws Exception {
	String methodName= new Throwable().getStackTrace()[0].getMethodName();
    driver.get(sAppURL);
    //MainApp_function(driver,FunctionEnum.assignMar); //select assign mar from search mar page
    addFacility_function(driver, facilityType, facilityName, Intreval,Venue,methodName+" addFacilityFunction test case "+testCaseNumber);
    verifyaddFacilityErrorMessages(driver,facilitytypeerror, facilitynameerror,methodName+" addFacilityErrorMsgsFunction test case "+testCaseNumber);
    //logout(driver,methodName+" addFacilityFunction test case "+testCaseNumber);
   // viewFacility_function(driver,methodName+" ViewFacilityFunction test case ");
    
  }
  
  public void searchMAR_function (WebDriver driver, String Date, String snapShotName) throws InterruptedException {
	  //Thread.sleep(1000);
  		 driver.findElement(By.name(prop.getProperty("Txt_Login_Username"))).sendKeys("Facman");
		  //Thread.sleep(1000); 
		  driver.findElement(By.name(prop.getProperty("Txt_Login_Password"))).sendKeys("F12345");			   
		   driver.findElement(By.xpath(prop.getProperty("Btn_Login_Login"))).click();
		   Thread.sleep(1000);
		   driver.findElement(By.id(prop.getProperty("Txt_SearchMAR_date"))).sendKeys(Date);
		   //Thread.sleep(1000);
  	    driver.findElement(By.id(prop.getProperty("Btn_SearchMAR_searchmar"))).click(); //select search mar from Facility manager's Home
  	 // Thread.sleep(1000);
  }
  public void verifysearchMARErrorMessages (WebDriver driver,String dateerror, String snapShotName) throws InterruptedException {
	  	try {
	  		//Thread.sleep(1000);
		  	String p = driver.findElement(By.xpath(prop.getProperty("SearchMAR_dateError"))).getAttribute("value");
			//Thread.sleep(1000);
		    assertTrue(p.equals(dateerror));
		    snap.takeScreenshot(driver,snapShotName);
		    //Thread.sleep(1000);
	  	}
	  	catch(Exception e) {
	  		 System.out.println("catched exception search mar"+e);
	  	}
  }

  public void assignMAR_function (WebDriver driver, String Rname, String Date, String days, String snapShotName) throws InterruptedException {
	  //Thread.sleep(1000);
  		 driver.findElement(By.name(prop.getProperty("Txt_Login_Username"))).sendKeys("Facman");
		  //Thread.sleep(1000); 
		  driver.findElement(By.name(prop.getProperty("Txt_Login_Password"))).sendKeys("F12345");			   
		   driver.findElement(By.xpath(prop.getProperty("Btn_Login_Login"))).click();
		   Thread.sleep(1000);
		   driver.findElement(By.id("searchMARDate")).sendKeys(Date);
		   //Thread.sleep(1000);
  	       driver.findElement(By.id(prop.getProperty("Btn_SearchMAR_searchmar"))).click(); //select search mar from Facility manager's Home
  	   //  Thread.sleep(1000);
  	       driver.findElement(By.xpath(prop.getProperty("Btn_AssignMAR_assignmar"))).click(); //clicking assign in the 3rd row /entry in the table
  	     //Thread.sleep(1000);
  	   WebElement  z = driver.findElement(By.xpath(prop.getProperty("Dp_AssignMAR_assignedto")));
  	   System.out.println("z"+z);
  	       new Select(z).selectByVisibleText(Rname);
  	     //Thread.sleep(1000);
  	       driver.findElement(By.xpath(prop.getProperty("Txt_AssignMAR_date"))).sendKeys(Date);
  	     //Thread.sleep(1000);
  	      // new Select(driver.findElement(By.xpath(prop.getProperty("Dp_AssignMAR_estimateofrepair")))).selectByVisibleText(days);
  	     //Thread.sleep(1000);
  	       driver.findElement(By.xpath(prop.getProperty("Btn_AssignMAR_updatemar"))).click();
  	     //Thread.sleep(1000);
  	   //driver.findElement(By.id(prop.getProperty("AssignMar_logout"))).click();
  }
  public void viewFacility_function (WebDriver driver,String snapShotName) throws InterruptedException {
	  //Thread.sleep(1000);
  		 driver.findElement(By.name(prop.getProperty("Txt_Login_Username"))).sendKeys("Facman");
		  //Thread.sleep(1000); 
		  driver.findElement(By.name(prop.getProperty("Txt_Login_Password"))).sendKeys("F12345");			   
		   driver.findElement(By.xpath(prop.getProperty("Btn_Login_Login"))).click();
		   Thread.sleep(1000);
		   
		   
		   driver.findElement(By.id(prop.getProperty("Btn_SearchFacility"))).click();
		   //Thread.sleep(1000);
		   driver.findElement(By.id(prop.getProperty("AssignMar_logout"))).click();
		   
		   driver.findElement(By.name(prop.getProperty("Txt_Login_Username"))).sendKeys("Facman");
			  //Thread.sleep(1000); 
			  driver.findElement(By.name(prop.getProperty("Txt_Login_Password"))).sendKeys("F12345");			   
			   driver.findElement(By.xpath(prop.getProperty("Btn_Login_Login"))).click();
			   
			   
		   
  }
  
  public void addFacility_function (WebDriver driver,String facilityType, String facilityName,String Intreval, String Venue, String snapShotName) throws InterruptedException {
	  try {
	  //Thread.sleep(1000);
  		 driver.findElement(By.name(prop.getProperty("Txt_Login_Username"))).sendKeys("Facman");
		  //Thread.sleep(1000); 
		  driver.findElement(By.name(prop.getProperty("Txt_Login_Password"))).sendKeys("F12345");			   
		   driver.findElement(By.xpath(prop.getProperty("Btn_Login_Login"))).click();
		   //Thread.sleep(1000);
		   
		   driver.findElement(By.xpath(prop.getProperty("Btn_AddFacility"))).click();
		   Thread.sleep(1000);
		   			   
		   driver.findElement(By.xpath(prop.getProperty("txt_addFacility_FacilityType"))).sendKeys(facilityType);
			  Thread.sleep(1000); 
			  driver.findElement(By.xpath(prop.getProperty("txt_addFacility_FacilityName"))).sendKeys(facilityName);	
			  
			  new Select(driver.findElement(By.name(prop.getProperty("lst_addFacility_Intreval")))).selectByVisibleText(Intreval);  
			  //Thread.sleep(1000);
			  new Select(driver.findElement(By.name(prop.getProperty("lst_addFacility_Venue")))).selectByVisibleText(Venue);  
			  //Thread.sleep(1000);
			   driver.findElement(By.xpath(prop.getProperty("Btn_submitAddFacility"))).click();
			   Thread.sleep(1000);
					   
		if(facilityType.equals("Multipurpose Rooms") && facilityName.contentEquals("MR1")){
			driver.findElement(By.id(prop.getProperty("addfacility_logout"))).click();
					   }
			  }
	  catch(Exception e) {
		  System.out.println("E"+e);
	  }
			   				 
		   
  }
  

  public void verifyaddFacilityErrorMessages (WebDriver driver,String facilitytypeerror, String facilitynameerror, String snapShotName) throws InterruptedException {
	  //  assertTrue(driver.findElement(By.xpath(prop.getProperty("insertCompany_errMsgError"))).getAttribute("value").equals(errorMsg));
	  try {
	  Thread.sleep(1000);  
	 String p = driver.findElement(By.xpath(prop.getProperty("addFacilityTypeError"))).getAttribute("value");
	 System.out.println("p"+p);
	  assertTrue(p.equals(facilitytypeerror));
	  Thread.sleep(1000); 
	    assertTrue(driver.findElement(By.xpath(prop.getProperty("addFacilityNameError"))).getAttribute("value").equals(facilitynameerror));
	    snap.takeScreenshot(driver,snapShotName);
	  }
	  catch(Exception e) {
		  
	  }
  }
  
  
  
  public void viewSpecificFacility_function (WebDriver driver,String facilityType, String facilityName, String snapShotName) throws InterruptedException {
	  //Thread.sleep(1000);
  		 driver.findElement(By.name(prop.getProperty("Txt_Login_Username"))).sendKeys("Facman");
		  //Thread.sleep(1000); 
		  driver.findElement(By.name(prop.getProperty("Txt_Login_Password"))).sendKeys("F12345");			   
		   driver.findElement(By.xpath(prop.getProperty("Btn_Login_Login"))).click();
		   Thread.sleep(1000); 
		   
		   new Select(driver.findElement(By.xpath(prop.getProperty("Lst_SpecificFacility_facilitytype")))).selectByVisibleText(facilityType);  
			  //Thread.sleep(1000);
			  new Select(driver.findElement(By.xpath(prop.getProperty("Lst_SpecificFacility_facilityname")))).selectByVisibleText(facilityName);  
			  //Thread.sleep(1000);
		   
		   driver.findElement(By.xpath(prop.getProperty("view_facility_details"))).click(); 
		   //Thread.sleep(1000);
/*
 * driver.findElement(By.id(prop.getProperty("viewfacility_logout"))).click();
 * 
 * driver.findElement(By.name(prop.getProperty("Txt_Login_Username"))).sendKeys(
 * "Facman"); //Thread.sleep(1000);
 * driver.findElement(By.name(prop.getProperty("Txt_Login_Password"))).sendKeys(
 * "F12345");
 * driver.findElement(By.xpath(prop.getProperty("Btn_Login_Login"))).click();
 */
		   
  }
  
  
  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }
}

